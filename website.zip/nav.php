<nav>
    <div class="logo">
        <a href="index.php">Nepali Restaurant</a>
    </div>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="menu.php">Menu</a></li>
		 <li><a href="order.php" class="order-now">Order Now</a></li>
        <li><a href="reservations.php">Reservation</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="feedback.php">Feedback</a></li>
       
    </ul>
</nav>
