<?php
session_start();

// Include your database connection
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    // Admin login
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM admins WHERE username='$username'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_logged_in'] = true;
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "Username not found!";
    }
}

if (isset($_GET['logout'])) {
    // Logout functionality
    session_destroy();
    header('Location: admin_panel.php');
}

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    // Admin dashboard and menu management
    if (isset($_POST['add_item'])) {
        // Add new menu item
        $item_name = $_POST['item_name'];
        $price = $_POST['price'];

        $query = "INSERT INTO menu (item_name, price) VALUES ('$item_name', '$price')";
        if ($conn->query($query) === TRUE) {
            $message = "New menu item added successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }

    if (isset($_GET['delete'])) {
        // Delete menu item
        $id = $_GET['delete'];
        $query = "DELETE FROM menu WHERE id=$id";
        if ($conn->query($query) === TRUE) {
            $message = "Menu item deleted successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Panel</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-color: #f4f4f9;
                margin: 0;
                padding: 0;
            }

            h1 {
                color: #D9534F;
                text-align: center;
                padding: 20px;
            }

            a {
                color: #5bc0de;
                text-decoration: none;
                margin: 20px;
            }

            a:hover {
                text-decoration: underline;
            }

            form {
                background-color: #ffffff;
                padding: 20px;
                margin: 20px auto;
                width: 80%;
                border-radius: 8px;
                box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
                text-align: center;
            }

            input, button {
                margin: 10px 0;
                padding: 10px;
                width: 80%;
                font-size: 16px;
            }

            table {
                width: 80%;
                margin: 20px auto;
                border-collapse: collapse;
            }

            table, th, td {
                border: 1px solid #ddd;
            }

            th, td {
                padding: 12px;
                text-align: left;
            }

            td a {
                color: #D9534F;
                text-decoration: none;
            }

            td a:hover {
                text-decoration: underline;
            }

            .message {
                text-align: center;
                color: green;
                font-weight: bold;
            }

            .error {
                text-align: center;
                color: red;
                font-weight: bold;
            }
        </style>
    </head>
    <body>

    <h1>Admin Dashboard</h1>

    <a href="admin_panel.php?logout=true">Logout</a>

    <h2>Manage Menu</h2>
    <form method="POST" action="">
        <label for="item_name">Item Name:</label>
        <input type="text" id="item_name" name="item_name" required>
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" required>
        <button type="submit" name="add_item">Add Item</button>
    </form>

    <?php if (isset($message)) { echo "<p class='message'>$message</p>"; } ?>

    <h3>Menu Items</h3>
    <table>
        <tr>
            <th>Item Name</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
        <?php
        $query = "SELECT * FROM menu";
        $result = $conn->query($query);
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['item_name'] . "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "<td><a href='admin_panel.php?delete=" . $row['id'] . "'>Delete</a></td>";
            echo "</tr>";
        }
        ?>
    </table>

    </body>
    </html>
    <?php
} else {
    // Login form
    if (isset($error)) {
        echo "<p class='error'>$error</p>";
    }
    ?>
    <h1>Admin Login</h1>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit" name="login">Login</button>
    </form>
    <?php
}

$conn->close();
?>
