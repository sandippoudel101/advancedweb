<footer>
    <div class="footer-container">
        <p>&copy; <?php echo date("Y"); ?> Your Restaurant Name. All rights reserved.</p>
        <p>Follow us: 
            <a href="https://www.facebook.com" target="_blank">Facebook</a> | 
            <a href="https://www.instagram.com" target="_blank">Instagram</a> | 
            <a href="https://www.twitter.com" target="_blank">Twitter</a>
        </p>
    </div>
</footer>

