<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu | Nepali Restaurant</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* General Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            color: #fff;
            background: url('https://t3.ftcdn.net/jpg/02/05/87/60/360_F_205876015_hYYs7ugqoU8QAobSS3TbnGQ92qyS5gEc.jpg') no-repeat center center/cover;
            background-size: cover;
            overflow-x: hidden;
        }

        h2 {
            font-size: 2.5rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        p {
            font-size: 1.2rem;
            color: #f0a500;
        }

        /* Content Section */
        .content {
            position: relative;
            z-index: 1;
            text-align: center;
            padding: 60px 20px;
            background: rgba(0, 0, 0, 0.6);
        }

        /* Food Grid */
        .food-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .food-item {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .food-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }

        .food-item img {
            max-width: 100%;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .food-item p {
            font-size: 1.2rem;
            color: #333;
            margin: 0;
        }

        /* Button Style */
        .btn {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 30px;
            font-size: 1rem;
            color: #fff;
            background: #f0a500;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background: #b12704;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            h2 {
                font-size: 2rem;
            }

            p {
                font-size: 1rem;
            }

            .food-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
            }
        }
    </style>
</head>

<body>

    <?php include 'nav.php'; ?>

    <!-- Main Content -->
    <div class="content">
        <h2>Our Menu</h2>
        <p>Explore our authentic Nepali dishes, crafted with love and tradition.</p>

        <!-- Food Grid -->
        <div class="food-grid">
            <div class="food-item">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHh0vMiW1W7bBKpLKoR6miD_xQzr52iFGaqw&s" alt="Momo">
                <p>Momo</p>
            </div>
            <div class="food-item">
                <img src="https://cdn.shopify.com/s/files/1/0223/0981/files/Dal_Bhat_from_Nepal_curry_dhal_lentils_spinach_rice_yogurt.jpg?v=1618366911" alt="Nepali Dal Bhat">
                <p>Nepali Dal Bhat</p>
            </div>
            <div class="food-item">
                <img src="https://jackslobodian.com/wp-content/uploads/2021/03/Vegetable-Vegan-Chow-Mein-2.jpg" alt="Chowmein">
                <p>Chowmein</p>
            </div>
            <div class="food-item">
                <img src="https://img.freepik.com/premium-photo/newari-khaja-set-typical-nepali-thali-with-rice-flakes-choyila-eggs-chickpeas-aalu-sadheko-lunch_723123-4223.jpg" alt="Newari Kaja Set">
                <p>Newari Kaja Set</p>
            </div>
            <div class="food-item">
                <img src="https://preview.redd.it/oz54jve5z0s61.jpg?width=640&crop=smart&auto=webp&s=83b9ef28b5bb784a290f2246001a11a23d820995" alt="Thukpa">
                <p>Thukpa</p>
            </div>
        </div>

        <?php include 'footer.php'; ?>

</body>

</html>
