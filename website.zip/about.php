<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | Nepali Restaurant</title>
    <style>
        /* General body styles */
        body {
            font-family: 'Roboto', sans-serif;
            background: url('https://t3.ftcdn.net/jpg/02/05/87/60/360_F_205876015_hYYs7ugqoU8QAobSS3TbnGQ92qyS5gEc.jpg') no-repeat center center/cover;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: white;
            text-align: center;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Navigation bar */
        nav {
            background-color: rgba(0, 0, 0, 0.7);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            padding: 20px 30px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: color 0.3s;
        }

        nav ul li a:hover {
            color: #f0a500;
        }

        /* Hero section */
        .hero {
            position: relative;
            padding: 80px 20px;
            background: rgba(0, 0, 0, 0.5);
            color: #fff;
        }

        .hero h1 {
            font-size: 60px;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin: 0;
        }

        .hero p {
            font-size: 20px;
            margin-top: 10px;
            line-height: 1.5;
        }

        /* Content section */
        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 30px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
        }

        .container h2 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        .container p {
            font-size: 20px;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        /* Footer styling */
        footer {
            background: #333;
            color: white;
            padding: 20px 0;
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            font-size: 16px;
        }

        footer a {
            color: #f0a500;
            text-decoration: none;
            font-weight: bold;
        }

        footer a:hover {
            color: white;
            text-decoration: underline;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 40px;
            }

            .hero p {
                font-size: 16px;
            }

            .container {
                padding: 20px;
                margin: 20px;
            }

            nav ul {
                flex-direction: column;
            }

            nav ul li {
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navigation Menu -->
<?php include 'nav.php'; ?>

<!-- Hero Section -->
<div class="hero">
    <h1>About Us</h1>
    <p>Learn more about our authentic Nepali cuisine and what makes us special.</p>
</div>

<!-- Main content section -->
<div class="container">
    <h2>Welcome to Our Nepali Restaurant</h2>
    <p>At our Nepali restaurant, we offer an authentic taste of Nepal. Our menu features a range of dishes crafted from traditional Nepali recipes, prepared using fresh ingredients and time-honored methods. Whether you're a lover of spicy foods or enjoy mild flavors, we have something to satisfy every palate.</p>
    <p>Our mission is to bring the rich culinary heritage of Nepal to Australia, providing our guests with a memorable dining experience in a warm and welcoming environment.</p>
</div>

<?php include 'footer.php'; ?>

</body>
</html>
