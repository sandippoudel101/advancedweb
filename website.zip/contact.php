<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Nepali Restaurant</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif; /* Modern, elegant font */
            background-color: #f8f1e5; /* Warm, earthy background */
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            overflow-x: hidden; /* Prevent horizontal scrolling */
        }

        header {
            background-color: #8B0000; /* Deep red (inspired by Nepalese flag) */
            color: white;
            padding: 8px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        header h1 {
            font-size: 30px;
            font-weight: bold;
            text-transform: uppercase;
            margin-left: 20px;
            color: #FFD700; /* Gold color */
            font-family: 'Merienda', cursive;
        }

        header p {
            font-size: 14px;
        }

        .contact-container {
            display: flex;
            justify-content: center;
            padding: 50px;
        }

        .contact-info {
            width: 50%;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-right: 30px;
            border-radius: 10px;
        }

        .contact-info h2 {
            color: #8B0000;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .contact-info p {
            color: #7f8c8d;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .contact-form {
            width: 50%;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .contact-form h2 {
            color: #8B0000;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .contact-form button {
            width: 100%;
            padding: 12px;
            background-color: #D2691E; /* Warm brown */
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .contact-form button:hover {
            background-color: #A0522D; /* Darker brown */
        }

        footer {
            background-color: #8B0000;
            color: white;
            padding: 15px 0;
            text-align: center;
        }

        .map-container {
            width: 100%;
            height: 400px;
            margin-top: 30px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            header {
                flex-direction: column;
                padding: 10px;
                text-align: center;
            }

            .contact-container {
                flex-direction: column;
                padding: 20px;
            }

            .contact-info, .contact-form {
                width: 90%;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

<?php include 'nav.php'; ?>

<header>
    <h1>Contact Nepali Restaurant</h1>
    <p>We'd love to hear from you! Reach out to us for any inquiries or reservations.</p>
</header>

<div class="contact-container">
    <!-- Contact Info Section -->
    <div class="contact-info">
        <h2>Our Location</h2>
        <p><strong>Address:</strong> 123 Nepali Street, Sydney, Australia</p>
        <p><strong>Phone:</strong> +61 123 456 789</p>
        <p><strong>Email:</strong> info@nepalirestaurant.com.au</p>
        <p><strong>Opening Hours:</strong></p>
        <ul>
            <li>Monday - Friday: 11:00 AM - 9:00 PM</li>
            <li>Saturday - Sunday: 12:00 PM - 10:00 PM</li>
        </ul>
    </div>

    <!-- Contact Form Section -->
    <div class="contact-form">
        <h2>Send Us a Message</h2>
        <form action="" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
        </form>
    </div>
</div>

<!-- Google Map Integration -->
<div class="map-container">
    <iframe src="https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=123+Nepali+Street,+Sydney,+Australia" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<footer>
    <p>&copy; 2025 Nepali Restaurant. All rights reserved.</p>
</footer>

</body>
</html>

<?php
// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize user input
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Check if all fields are filled
    if (!empty($name) && !empty($email) && !empty($message)) {
        // Insert into the database
        $sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$message')";
        
        if (mysqli_query($conn, $sql)) {
            // Redirect after success
            echo "<script>alert('Message sent successfully!'); window.location.href='contact.php';</script>";
        } else {
            // Error handling
            echo "<script>alert('Error: " . mysqli_error($conn) . "'); window.location.href='contact.php';</script>";
        }
    } else {
        echo "<script>alert('Please fill in all fields'); window.location.href='contact.php';</script>";
    }
}
?>
