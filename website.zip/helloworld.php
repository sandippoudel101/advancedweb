<html>
<head>
    <title>First PHP Code</title>
</head>
<body>
    <h1>
        <?php
        echo "Hello World";
        ?>
    </h1>
</body>
</html>
