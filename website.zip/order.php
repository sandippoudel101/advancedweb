<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture order details
    $customer_name = $_POST['customer_name'];
    $orders = [];

    // Loop through all menu items and capture order details
    foreach ($_POST['dishes'] as $dish_id => $quantity) {
        if ($quantity > 0) {
            // Fetch the dish name from the menu
            $sql = "SELECT name FROM menu WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $dish_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $dish = $result->fetch_assoc();

            $orders[] = [
                'dish_name' => $dish['name'],
                'quantity' => $quantity
            ];
        }
    }

    // Insert order details into the orders table
    if (!empty($orders)) {
        foreach ($orders as $order) {
            $sql = "INSERT INTO orders (customer_name, dish_name, quantity, order_date) VALUES (?, ?, ?, NOW())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $customer_name, $order['dish_name'], $order['quantity']);
            $stmt->execute();
        }
        $message = "Your order has been successfully placed!";
    } else {
        $message = "Please select at least one dish.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order | Nepali Restaurant</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'nav.php'; ?>

<h2>Place Your Order</h2>

<?php if (isset($message)) { echo "<p>$message</p>"; } ?>

<form action="order.php" method="POST">
    <label for="customer_name">Your Name:</label>
    <input type="text" name="customer_name" id="customer_name" required>

    <div class="menu-items">
        <?php
        $sql = "SELECT * FROM menu";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            ?>
            <div class="menu-item">
                <label for="dish-<?php echo $row['id']; ?>"><?php echo $row['name']; ?> (AUD <?php echo number_format($row['price'], 2); ?>)</label>
                <input type="number" name="dishes[<?php echo $row['id']; ?>]" id="dish-<?php echo $row['id']; ?>" min="0" placeholder="Quantity" value="0">
            </div>
            <?php
        }
        ?>
    </div>

    <button type="submit">Submit Order</button>
</form>

<?php include 'footer.php'; ?>

</body>
</html>
